# Scootin_Android_App
Scootin' stop watch android application.

A very simple and easy to use stop watch to get you scooting. Perfect for every timing situation including cooking, sports, 
games and work tasks. 
It is an early acess version that soon will be extremely intersting and always open source for educational use.


